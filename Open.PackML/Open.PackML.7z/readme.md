# Open.PackML
Open prewritten classes for building control systems using the OMAC ISA-88 PackML standard in c# programs.
Currently In alpha state but is already being in use.