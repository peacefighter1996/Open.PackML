﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Open.PackML
{
    public class Warning
    {
        public int Id { get; }
        public Warning(int Id)
        {
            this.Id = Id;
        }
    }
}
