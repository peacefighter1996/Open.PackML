﻿namespace Open.PackML
{
    //https://medium.com/kb-controls/packml-essentials-610063f66138
    public enum Mode
    {
        Production,
        Maintenance,
        Manual,
    }
}